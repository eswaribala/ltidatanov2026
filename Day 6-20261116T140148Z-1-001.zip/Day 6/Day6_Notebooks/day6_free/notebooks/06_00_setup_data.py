# Databricks notebook source
# MAGIC %md
# MAGIC # Day 6 - Setup: sales (6,000,000 rows), stores (50), products (20,000)
# MAGIC Databricks Free Edition: attach to **Serverless** (compute selector, top right), then Run all. Takes about 1-2 minutes.

# COMMAND ----------

# Cell 1 - your schema (workspace.day6_<you>)
import re
me = spark.sql("SELECT current_user()").first()[0]
SCHEMA = "day6_" + re.sub(r"[^a-z0-9]", "_", me.split("@")[0].lower())

# Use the current active catalog instead of hardcoding 'workspace'
current_catalog = spark.sql("SELECT current_catalog()").first()[0]
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {current_catalog}.{SCHEMA}")
spark.sql(f"USE {SCHEMA}")

print(f"Working in: {current_catalog}.{SCHEMA} | shuffle partitions:", spark.conf.get("spark.sql.shuffle.partitions"))

# COMMAND ----------

# Cell 2 - deterministic data: same rows for every learner, so results can be checked exactly
spark.sql("""
CREATE OR REPLACE TABLE sales AS
SELECT id                                                         AS sale_id,
       CAST(id % 50 + 1 AS INT)                                   AS store_id,
       CAST((id div 3) % 20000 + 1 AS INT)                        AS product_id,
       date_add(DATE'2026-01-01', CAST((id div 11) % 90 AS INT))  AS sale_date,
       CAST((id div 50) % 5 + 1 AS INT)                           AS qty,
       CAST(((id div 7) % 1000 + 1) / 10 AS DECIMAL(10,2))        AS unit_price
FROM range(6000000)
""")
spark.sql("""
CREATE OR REPLACE TABLE stores AS
SELECT CAST(id AS INT)                                                        AS store_id,
       concat('Store-', lpad(CAST(id AS STRING), 2, '0'))                     AS store_name,
       element_at(array('North','South','East','West','Central'), CAST(id % 5 AS INT) + 1) AS region
FROM range(1, 51)
""")
spark.sql("""
CREATE OR REPLACE TABLE products AS
SELECT CAST(id AS INT)                                                 AS product_id,
       concat('Product-', lpad(CAST(id AS STRING), 5, '0'))            AS product_name,
       concat('CAT-', lpad(CAST(id % 20 AS STRING), 2, '0'))           AS category
FROM range(1, 20001)
""")

# COMMAND ----------

# Cell 3 - check. Expected: 6000000 | 909342857.20 | 50 | 20000
display(spark.sql("""
SELECT (SELECT COUNT(*) FROM sales)                    AS sales_rows,
       (SELECT SUM(qty * unit_price) FROM sales)       AS total_revenue,
       (SELECT COUNT(*) FROM stores)                   AS stores,
       (SELECT COUNT(*) FROM products)                 AS products
"""))
