# Databricks notebook source
# MAGIC %md
# MAGIC # Day 6 Lab 2 (Free Edition) - Broadcast vs Shuffle Join & Adaptive Query Execution
# MAGIC Attach to **Serverless**. Run ONE cell at a time. Evidence of what really ran: **See performance → See query profile**.

# COMMAND ----------

# Cell 1 - context, helpers and the regional revenue query
import re
me = spark.sql("SELECT current_user()").first()[0]
SCHEMA = "day6_" + re.sub(r"[^a-z0-9]", "_", me.split("@")[0].lower())

current_catalog = spark.sql("SELECT current_catalog()").first()[0]
spark.sql(f"USE CATALOG {current_catalog}")
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {SCHEMA}")
spark.sql(f"USE SCHEMA {SCHEMA}")

print(f"Working in: {current_catalog}.{SCHEMA} | shuffle partitions:", spark.conf.get("spark.sql.shuffle.partitions"))
import io, contextlib, time

def plan_text(df, mode="simple"):
    """Capture df.explain() output as text (works on serverless / Spark Connect)."""
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        df.explain(mode=mode) if mode != "simple" else df.explain()
    return buf.getvalue()

def lines_with(df, words):
    return [l.strip(" +-:*") for l in plan_text(df).splitlines() if any(w in l for w in words)]

def timed(df):
    t0 = time.time(); rows = df.collect(); return rows, round(time.time() - t0, 1)

QUERY = """
SELECT {hint} st.region, COUNT(*) AS sales_rows, SUM(s.qty * s.unit_price) AS revenue
FROM sales s JOIN stores st ON s.store_id = st.store_id
GROUP BY st.region
ORDER BY st.region
"""
JOIN_WORDS = ("Join", "Exchange", "AdaptiveSparkPlan")

# COMMAND ----------

# Cell 2 - BROADCAST join: plan
bhj = spark.sql(QUERY.format(hint="/*+ BROADCAST(st) */"))
bhj.explain(mode="formatted")

# COMMAND ----------

# Cell 3 - BROADCAST join: run
rows, secs = timed(bhj)
print("broadcast join:", secs, "s")
for r in rows: print(r)

# COMMAND ----------

# Cell 4 - SHUFFLE join (sort-merge hint): plan and run
smj = spark.sql(QUERY.format(hint="/*+ SHUFFLE_MERGE(st) */"))
smj.explain(mode="formatted")
rows2, secs2 = timed(smj)
print("shuffle join:", secs2, "s   same result as broadcast:", rows == rows2)

# COMMAND ----------

# Cell 5 - side by side: join operator and exchanges of each plan
for name, df in [("BROADCAST", bhj), ("SHUFFLE_MERGE", smj)]:
    print("=====", name)
    for l in lines_with(df, ("Join", "Exchange")): print("  ", l[:130])

# COMMAND ----------

# Cell 6 - AQE: the optimizer over-estimates a tiny filtered side; the INITIAL plan cannot broadcast it.
#          Run it, then compare with the query profile (what really ran).
aqe = spark.sql("""
SELECT COUNT(*) AS matched, SUM(s.qty * s.unit_price) AS revenue
FROM sales s
JOIN (SELECT sale_id FROM sales WHERE sale_id % 120000 = 0) t ON s.sale_id = t.sale_id
""")
print("---- INITIAL plan (explain, before execution)")
for l in lines_with(aqe, JOIN_WORDS): print("  ", l[:130])
rows3, secs3 = timed(aqe)
print("---- result:", rows3[0], f"({secs3} s)  -> now open See performance -> See query profile")

# COMMAND ----------

# Cell 7 - shuffle partitions: the ONE shuffle setting you can change on serverless
for value in ("200", "8", "auto"):
    spark.conf.set("spark.sql.shuffle.partitions", value)
    df = spark.table("sales").groupBy("product_id").count()
    ex = lines_with(df, ("Exchange",))
    _, secs = timed(df)
    print(f"shuffle.partitions={value:5s}  {secs:5.1f} s   {ex[0][:110] if ex else ''}")
print("restored:", spark.conf.get("spark.sql.shuffle.partitions"))
