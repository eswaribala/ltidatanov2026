# Databricks notebook source
# MAGIC %md
# MAGIC # Day 6 Lab 1 (Free Edition) - Spark Execution Plans & Shuffle Operations
# MAGIC Attach to **Serverless**. Run ONE cell at a time and compare the output with the lab guide.
# MAGIC The Spark UI does not exist on serverless: use **See performance → See query profile** under a cell instead.

# COMMAND ----------

# Cell 1 - context and helpers (Using your active kraft_brick catalog and schema)
import re
me = spark.sql("SELECT current_user()").first()[0]
SCHEMA = "day6_" + re.sub(r"[^a-z0-9]", "_", me.split("@")[0].lower())

# Get current active catalog (kraft_brick)
current_catalog = spark.sql("SELECT current_catalog()").first()[0]
spark.sql(f"USE CATALOG {current_catalog}")
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {SCHEMA}")
spark.sql(f"USE SCHEMA {SCHEMA}")

print(f"Working in: {current_catalog}.{SCHEMA} | shuffle partitions:", spark.conf.get("spark.sql.shuffle.partitions"))

import io, contextlib, time

def plan_text(df, mode="simple"):
    """Capture df.explain() output as text (works on serverless / Spark Connect)."""
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        df.explain(mode=mode) if mode != "simple" else df.explain()
    return buf.getvalue()

def lines_with(df, words):
    return [l.strip(" +-:*") for l in plan_text(df).splitlines() if any(w in l for w in words)]

def timed(df):
    t0 = time.time(); rows = df.collect(); return rows, round(time.time() - t0, 1)

# COMMAND ----------

# Cell 2 - the query under investigation, and ALL its plans (parsed, analyzed, optimized logical, physical)
q1 = spark.sql("""
SELECT store_id, COUNT(*) AS orders, SUM(qty * unit_price) AS revenue
FROM sales
WHERE sale_date >= DATE'2026-03-01'
GROUP BY store_id
ORDER BY revenue DESC
""")
q1.explain(mode="extended")

# COMMAND ----------

# Cell 3 - the physical plan in numbered, readable form (nothing has run yet: this is the INITIAL plan)
q1.explain(mode="formatted")

# COMMAND ----------

# Cell 4 - run it and time it. Afterwards: See performance (under this cell) -> the query -> See query profile
rows, secs = timed(q1)
print(f"elapsed: {secs} s   stores: {len(rows)}   total revenue: {sum(r.revenue for r in rows)}")
for r in rows[:3]:
    print(r)

# COMMAND ----------

# Cell 5 - which operations shuffle? (an Exchange in the physical plan = a shuffle)
sales = spark.table("sales")
tests = {
    "narrow : filter + select":     sales.filter("qty > 3").select("sale_id", "qty"),
    "wide   : groupBy(product_id)": sales.groupBy("product_id").count(),
    "wide   : repartition(8)":      sales.repartition(8),
    "wide   : orderBy(unit_price)": sales.orderBy("unit_price"),
}
for name, df in tests.items():
    ex = lines_with(df, ("Exchange",))
    print(f"{name:30s} exchanges={len(ex)}  {ex[0][:100] if ex else ''}")

# COMMAND ----------

# Cell 6 - run the groupBy; then open its query profile (See performance) and find the shuffle
agg = sales.groupBy("product_id").count()
res, secs = timed(agg)
print("groups:", len(res), " min count:", min(r["count"] for r in res), " max count:", max(r["count"] for r in res), f" ({secs} s)")
