# Databricks notebook source
# MAGIC %md
# MAGIC # Day 6 Lab 3 (Free Edition) - Delta OPTIMIZE, Time Travel, Schema Evolution & VACUUM
# MAGIC Attach to **Serverless**. Run ONE cell at a time. Cell 11 deletes old files PERMANENTLY - only in your own table.

# COMMAND ----------

# Cell 1 - context (serverless: Spark settings cannot switch off auto compaction - the TABLE PROPERTIES in Cell 2 do it)
import re
me = spark.sql("SELECT current_user()").first()[0]
SCHEMA = "day6_" + re.sub(r"[^a-z0-9]", "_", me.split("@")[0].lower())

current_catalog = spark.sql("SELECT current_catalog()").first()[0]
spark.sql(f"USE CATALOG {current_catalog}")
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {SCHEMA}")
spark.sql(f"USE SCHEMA {SCHEMA}")

print(f"Working in: {current_catalog}.{SCHEMA} | shuffle partitions:", spark.conf.get("spark.sql.shuffle.partitions"))

# COMMAND ----------

# Cell 2 - create the table and append 20 small batches (20 x 50,000 rows, 10 files each)
spark.sql("DROP TABLE IF EXISTS events")
spark.sql("""
CREATE TABLE events (device_id INT, reading_ts TIMESTAMP, temperature DOUBLE, batch_no INT)
TBLPROPERTIES ('delta.autoOptimize.optimizeWrite' = 'false', 'delta.autoOptimize.autoCompact' = 'false')
""")
for b in range(1, 21):
    (spark.range(50000)
        .selectExpr("CAST(id % 500 AS INT) AS device_id",
                    f"timestamp_seconds(1772323200 + {b} * 3600 + id) AS reading_ts",
                    "round(20 + (id % 150) / 10.0, 1) AS temperature",
                    f"{b} AS batch_no")
        .repartition(10)
        .write.mode("append").saveAsTable("events"))
print("done")

# COMMAND ----------

# Cell 3 - the small-file problem: files, size, versions
display(spark.sql("DESCRIBE DETAIL events").select("numFiles", "sizeInBytes"))
print("rows:", spark.table("events").count(), "  versions:", spark.sql("DESCRIBE HISTORY events").count())

# COMMAND ----------

# Cell 4 - benchmark query BEFORE optimize (run twice, keep the second time)
import time
def bench():
    t0 = time.time()
    r = spark.sql("SELECT COUNT(*) AS n, ROUND(AVG(temperature), 3) AS avg_t FROM events WHERE device_id = 42").first()
    return r, round(time.time() - t0, 2)
bench(); print(bench())

# COMMAND ----------

# Cell 5 - OPTIMIZE: compact the small files
display(spark.sql("OPTIMIZE events").select("metrics.numFilesRemoved", "metrics.numFilesAdded"))

# COMMAND ----------

# Cell 6 - after OPTIMIZE: files, history, benchmark
display(spark.sql("DESCRIBE DETAIL events").select("numFiles", "sizeInBytes"))
display(spark.sql("DESCRIBE HISTORY events").select("version", "operation", "operationMetrics.numRemovedFiles",
                                                     "operationMetrics.numAddedFiles").limit(3))
bench(); print(bench())

# COMMAND ----------

# Cell 7 - TIME TRAVEL: read old versions by number and by timestamp
for v in (10, 20, 21):
    print(f"version {v}:", spark.sql(f"SELECT COUNT(*) FROM events VERSION AS OF {v}").first()[0])
ts = spark.sql("DESCRIBE HISTORY events").filter("version = 10").first()["timestamp"]
print("timestamp of v10:", ts, " rows:", spark.sql(f"SELECT COUNT(*) FROM events TIMESTAMP AS OF '{ts}'").first()[0])
print("rows that differ between v20 and v21:",
      spark.sql("SELECT * FROM events VERSION AS OF 21 EXCEPT ALL SELECT * FROM events VERSION AS OF 20").count())

# COMMAND ----------

# Cell 8 - SCHEMA EVOLUTION, attempt 1: new column 'firmware' WITHOUT mergeSchema
new = (spark.range(50000)
       .selectExpr("CAST(id % 500 AS INT) AS device_id",
                   "timestamp_seconds(1772409600 + id) AS reading_ts",
                   "round(25 + (id % 100) / 10.0, 1) AS temperature",
                   "21 AS batch_no",
                   "'v2.1' AS firmware"))
try:
    new.write.mode("append").saveAsTable("events")
    print("write succeeded (unexpected)")
except Exception as e:
    print("WRITE REJECTED:", str(e)[:400])

# COMMAND ----------

# Cell 9 - SCHEMA EVOLUTION, attempt 2: WITH mergeSchema
new.write.mode("append").option("mergeSchema", "true").saveAsTable("events")
display(spark.sql("""
SELECT COUNT(*) AS total_rows, COUNT(firmware) AS rows_with_firmware, COUNT(*) - COUNT(firmware) AS rows_firmware_null
FROM events"""))
print("columns now:", spark.table("events").columns)
print("columns in v21:", spark.sql("SELECT * FROM events VERSION AS OF 21").columns)

# COMMAND ----------

# Cell 10 - VACUUM with the default 7-day retention (DRY RUN = list only, delete nothing)
print("files VACUUM would delete (default retention):", spark.sql("VACUUM events DRY RUN").count())

# COMMAND ----------

# Cell 11 - shorten the table's retention to 5 minutes (LAB ONLY), dry run, vacuum, then restore 7 days.
#           Run this at least 5 minutes after Cell 5 (OPTIMIZE).
spark.sql("ALTER TABLE events SET TBLPROPERTIES ('delta.deletedFileRetentionDuration' = 'interval 5 minutes')")
print("files VACUUM would delete (5-minute retention):", spark.sql("VACUUM events DRY RUN").count())
spark.sql("VACUUM events")
spark.sql("ALTER TABLE events SET TBLPROPERTIES ('delta.deletedFileRetentionDuration' = 'interval 7 days')")
print("vacuum finished; retention restored to",
      spark.sql("SHOW TBLPROPERTIES events ('delta.deletedFileRetentionDuration')").first()["value"])

# COMMAND ----------

# Cell 12 - time travel AFTER vacuum
for v in (21, 10):
    try:
        print(f"version {v}:", spark.sql(f"SELECT COUNT(*) FROM events VERSION AS OF {v}").first()[0])
    except Exception as e:
        print(f"version {v}: FAILED -", str(e)[:250])
print("current rows:", spark.table("events").count())
