Day 6 Labs 1-3 - Databricks FREE EDITION (serverless) version
==============================================================
SET-UP (each learner, about 5 minutes)
  1. Sign up / sign in to Databricks Free Edition (https://www.databricks.com/learn/free-edition).
  2. Workspace > Home > Create > Folder "day6-labs" > Import the four .py files in notebooks/ (they become notebooks).
  3. Open 06_00_setup_data > compute selector (top right) > Serverless > Run all.
     Creates workspace.day6_<you>: sales 6,000,000 rows, stores 50, products 20,000.

WHAT CHANGED FROM THE CLASSIC-CLUSTER VERSION
  * Compute: Serverless (Photon always on, Spark Connect). No cluster to create. Catalog: workspace.
  * Spark UI -> Query Profile (cell: See performance > query > See query profile; or Query history).
  * Only six Spark properties can be set on serverless; the labs use only spark.sql.shuffle.partitions (default auto).
  * Lab 2: broadcast threshold / AQE switches cannot be changed -> AQE is shown with a mis-estimated filter
    (initial plan from explain() vs executed join in the Query Profile); Task 4 compares shuffle partitions 200/8/auto.
  * Lab 3: optimized writes / auto compaction off via TABLE PROPERTIES; VACUUM retention via the table property
    delta.deletedFileRetentionDuration (5 minutes for the demo, then restored to 7 days).
  * Free Edition has a daily compute quota: do not re-run set-up or heavy cells repeatedly.

EXPECTED VALUES (exact)
  Set-up: 6,000,000 rows, revenue 909,342,857.20; stores 50; products 20,000
  Lab 1: March 2,066,460 rows, 313,196,307.50, 50 stores, top store 50 = 6,472,657.50; groupBy 20,000 groups x 300
  Lab 2: regions 1,200,000 rows each; Central 181,919,999.90  East 181,817,142.70  North 181,971,428.50
         South 181,765,714.60  West 181,868,571.50;  AQE query: matched 50, revenue 2,102.90
  Lab 3: 200 files / 1,000,000 rows / 21 versions -> OPTIMIZE removes 200, adds 1; device 42 = 2000 rows, avg 29.15;
         v10 = 500,000; after schema evolution 1,050,000 (50,000 with firmware); VACUUM dry run 0 (7 days) / 200 (5 min)

CLEAN-UP after sign-off:  DROP SCHEMA workspace.day6_<you> CASCADE;
