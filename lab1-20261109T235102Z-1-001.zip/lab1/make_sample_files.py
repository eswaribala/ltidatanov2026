import csv
import json
from pathlib import Path

data_dir = Path("data")
data_dir.mkdir(exist_ok=True)

# Structured data: fixed columns and rows
with (data_dir / "store_sales.csv").open("w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(
        f,
        fieldnames=["store_id", "date", "category", "units_sold", "revenue"]
    )
    writer.writeheader()
    writer.writerows([
        {"store_id": 1, "date": "2026-03-01", "category": "Apparel", "units_sold": 10, "revenue": 250.00},
        {"store_id": 2, "date": "2026-03-02", "category": "Electronics", "units_sold": 3, "revenue": 899.97},
        {"store_id": 3, "date": "2026-03-03", "category": "Grocery", "units_sold": 20, "revenue": 100.00},
    ])

# Semi-structured data: nested objects and lists
clickstream = [
    {
        "event": "page_view",
        "timestamp": "2026-03-01T10:00:00",
        "user": {"user_id": "U9", "device": "mobile", "loyalty_tier": None},
        "filters": ["category", "price"]
    },
    {
        "event": "add_to_cart",
        "timestamp": "2026-03-01T10:05:00",
        "user": {"user_id": "U9", "device": "mobile"},
        "filters": []
    },
    {
        "event": "search",
        "timestamp": "2026-03-01T10:10:00",
        "user": {"user_id": "U4", "device": "web", "loyalty_tier": "gold"},
        "filters": ["brand"]
    }
]
(data_dir / "clickstream.json").write_text(
    json.dumps(clickstream, indent=2) + "\n", encoding="utf-8"
)

# Unstructured data: free-text customer reviews
(data_dir / "customer_reviews.txt").write_text(
    "The staff were helpful and checkout was quick.\n"
    "The product quality was good, but delivery arrived late.\n"
    "Great prices and a clean store; I will shop here again.\n",
    encoding="utf-8"
)

print("Created data/store_sales.csv")
print("Created data/clickstream.json")
print("Created data/customer_reviews.txt")
