from pathlib import Path

review_file = Path("data/customer_reviews.txt")

positive_words = {
    "helpful", "quick", "good", "great", "clean", "love",
    "excellent", "friendly", "easy", "recommend", "again"
}
negative_words = {
    "late", "bad", "poor", "broken", "slow", "damaged",
    "disappointed", "terrible", "issue", "problem"
}

def classify_sentiment(text):
    words = {
        word.strip(".,!?;:()[]{}\"'").lower()
        for word in text.split()
    }
    positive = len(words & positive_words)
    negative = len(words & negative_words)

    if positive > negative:
        return "POSITIVE"
    if negative > positive:
        return "NEGATIVE"
    return "NEUTRAL"

reviews = [
    line.strip()
    for line in review_file.read_text(encoding="utf-8").splitlines()
    if line.strip()
]

counts = {"POSITIVE": 0, "NEGATIVE": 0, "NEUTRAL": 0}

for index, review in enumerate(reviews, start=1):
    sentiment = classify_sentiment(review)
    counts[sentiment] += 1
    print(f"Review {index}: {sentiment} - {review}")

print("\nSentiment summary:")
for sentiment, count in counts.items():
    print(f"{sentiment}: {count}")
