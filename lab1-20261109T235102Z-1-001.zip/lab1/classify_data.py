import csv
import json
from pathlib import Path

data_dir = Path("data")

# Classify store sales CSV
with (data_dir / "store_sales.csv").open(
    newline="", encoding="utf-8"
) as f:
    reader = csv.DictReader(f)
    rows = list(reader)
    columns = reader.fieldnames or []

print(
    f"store_sales.csv -> STRUCTURED | {len(rows)} rows, "
    f"fixed columns {columns} (widths seen: "
    f"{len(columns)} columns)"
)

# Classify clickstream JSON
with (data_dir / "clickstream.json").open(encoding="utf-8") as f:
    events = json.load(f)

key_sets = {
    tuple(sorted(event.keys())) for event in events
}
nested_fields = sorted({
    key
    for event in events
    for key, value in event.items()
    if isinstance(value, (dict, list))
})

print(
    f"clickstream.json -> SEMI-STRUCTURED | {len(events)} records, "
    f"{len(key_sets)} different key-sets, nested fields: {nested_fields}"
)

# Classify customer reviews text
with (data_dir / "customer_reviews.txt").open(encoding="utf-8") as f:
    reviews = [line.strip() for line in f if line.strip()]

print(
    f"customer_reviews.txt -> UNSTRUCTURED | "
    f"{len(reviews)} lines of free text, no columns or keys"
)
