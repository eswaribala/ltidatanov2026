import json
import sqlite3
from pathlib import Path

json_path = Path("data/clickstream.json")
records = json.loads(json_path.read_text(encoding="utf-8"))

conn = sqlite3.connect(":memory:")
conn.execute("""
    CREATE TABLE clickstream (
        event TEXT,
        user_id TEXT,
        device TEXT,
        loyalty_tier TEXT
    )
""")

for record in records:
    user = record.get("user", {})
    conn.execute(
        "INSERT INTO clickstream VALUES (?, ?, ?, ?)",
        (
            record.get("event"),
            user.get("user_id"),
            user.get("device"),
            user.get("loyalty_tier"),
        ),
    )

rows = conn.execute("""
    SELECT event, user_id, device, loyalty_tier
    FROM clickstream
    ORDER BY rowid
""").fetchall()

print("event | user_id | device | loyalty_tier")
for row in rows:
    print(" | ".join(str(value) if value is not None else "None"
                     for value in row))

conn.close()
