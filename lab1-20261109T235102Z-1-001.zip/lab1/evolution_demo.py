import csv
import json
import shutil
import sqlite3
from pathlib import Path

DATA = Path("data")
LAKE = Path("lake/raw")
DB = Path("warehouse.db")

# Gen 2: strict warehouse (schema-on-write)
print("=== Gen 2: DATA WAREHOUSE (schema-on-write, STRICT table) ===")

conn = sqlite3.connect(DB)
conn.execute("PRAGMA foreign_keys = ON")
conn.execute("CREATE TABLE IF NOT EXISTS sales (store_id INTEGER NOT NULL, date TEXT NOT NULL, category TEXT NOT NULL, units_sold INTEGER NOT NULL, revenue REAL NOT NULL) STRICT")
conn.commit()

# Load CSV
try:
    with (DATA / "store_sales.csv").open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    conn.executemany(
        "INSERT INTO sales VALUES (?, ?, ?, ?, ?)",
        [
            (int(r["store_id"]), r["date"], r["category"],
             int(r["units_sold"]), float(r["revenue"]))
            for r in rows
        ],
    )
    conn.commit()
    print(f"  store_sales.csv    LOADED ({len(rows)} rows)")
except Exception as exc:
    conn.rollback()
    print(f"  store_sales.csv    REJECTED ({type(exc).__name__}: {exc})")

# Attempt to load JSON into a relational parameter
try:
    with (DATA / "clickstream.json").open(encoding="utf-8") as f:
        events = json.load(f)
    conn.execute(
        "INSERT INTO sales VALUES (?, ?, ?, ?, ?)",
        (events[0].get("event"), events[0].get("timestamp"),
         events[0].get("user"), events[0].get("filters"), 0.0),
    )
    conn.commit()
    print("  clickstream.json   LOADED")
except Exception as exc:
    conn.rollback()
    print(f"  clickstream.json   REJECTED ({type(exc).__name__}: {exc})")

# Attempt to load free text without a required store_id
try:
    with (DATA / "customer_reviews.txt").open(encoding="utf-8") as f:
        reviews = [line.strip() for line in f if line.strip()]
    conn.executemany(
        "INSERT INTO sales VALUES (?, ?, ?, ?, ?)",
        [(None, None, review, None, None) for review in reviews],
    )
    conn.commit()
    print("  customer_reviews.txt REJECTED (expected NOT NULL constraint)")
except Exception as exc:
    conn.rollback()
    print(f"  customer_reviews.txt REJECTED ({type(exc).__name__}: {exc})")

conn.close()

# Gen 3: raw lake accepts all source files as files
print("\n=== Gen 3: DATA LAKE (schema-on-read, raw files in object storage) ===")
LAKE.mkdir(parents=True, exist_ok=True)
for source in ("clickstream.json", "customer_reviews.txt", "store_sales.csv"):
    src = DATA / source
    dst = LAKE / source
    shutil.copy2(src, dst)
    print(f"  {source}  LOADED as-is -> {dst.as_posix()}")

print("\nWARNING: the lake accepted everything - nothing checked quality, schema or duplicates.")
