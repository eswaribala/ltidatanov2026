import sqlite3
import sys

if len(sys.argv) != 4:
    print("Usage: python3 place_order.py CUSTOMER_ID PRODUCT_ID QUANTITY")
    raise SystemExit(2)

customer_id, product_id, quantity = map(int, sys.argv[1:4])
conn = sqlite3.connect("retail_oltp.db")
conn.execute("PRAGMA foreign_keys = ON")

try:
    conn.execute("BEGIN")
    stock = conn.execute(
        "SELECT stock FROM products WHERE product_id = ?",
        (product_id,)
    ).fetchone()

    if stock is None:
        raise ValueError("Product not found")

    before = stock[0]
    print(f"Stock BEFORE: product {product_id} = {before}")

    price = conn.execute(
        "SELECT price FROM products WHERE product_id = ?",
        (product_id,)
    ).fetchone()[0]

    order = conn.execute(
        "INSERT INTO orders (customer_id, order_date, status) "
        "VALUES (?, date('now'), 'PLACED')",
        (customer_id,)
    )
    order_id = order.lastrowid

    conn.execute(
        "INSERT INTO order_items (order_id, product_id, quantity, unit_price) "
        "VALUES (?, ?, ?, ?)",
        (order_id, product_id, quantity, price)
    )

    conn.execute(
        "UPDATE products SET stock = stock - ? WHERE product_id = ?",
        (quantity, product_id)
    )

    conn.commit()
    after = conn.execute(
        "SELECT stock FROM products WHERE product_id = ?",
        (product_id,)
    ).fetchone()[0]
    total = conn.execute("SELECT COUNT(*) FROM orders").fetchone()[0]

    print(f"COMMITTED: order {order_id} -> Stock AFTER: {after}")
    print(f"Total orders now: {total}")

except (sqlite3.Error, ValueError) as exc:
    conn.rollback()
    after = conn.execute(
        "SELECT stock FROM products WHERE product_id = ?",
        (product_id,)
    ).fetchone()
    total = conn.execute("SELECT COUNT(*) FROM orders").fetchone()[0]
    print(f"ROLLED BACK: {exc}")
    print(f"Stock AFTER: {after[0] if after else 'UNKNOWN'}")
    print(f"Total orders now: {total}")
finally:
    conn.close()
