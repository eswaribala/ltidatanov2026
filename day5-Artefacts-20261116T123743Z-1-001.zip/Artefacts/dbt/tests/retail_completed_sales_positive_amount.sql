select
    transaction_id,
    sale_status,
    amount
from {{ ref('retail_sales_quality') }}
where lower(sale_status) = 'completed'
  and amount <= 0
