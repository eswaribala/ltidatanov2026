#!/usr/bin/env bash
set -euo pipefail

# Day 5 | DA-D5-503 | Scenario 2: create/update an ADF copy pipeline with a wrong source filename.
# Do not run the pipeline from this script. Participants run it in ADF Studio, inspect Monitor,
# fix the source dataset filename in the UI, publish, and rerun the same pipeline.

echo
echo "=== DA-D5-503 | Scenario 2: Incorrect Source Path ==="
echo

read -r -p "Participant ID [User01]: " PARTICIPANT_ID
PARTICIPANT_ID=${PARTICIPANT_ID:-User01}
read -r -p "Azure subscription ID (blank = current subscription): " SUBSCRIPTION_ID
read -r -p "Resource group [Kraft-Cadet]: " RESOURCE_GROUP
RESOURCE_GROUP=${RESOURCE_GROUP:-Kraft-Cadet}
read -r -p "Data Factory name [kraft-datafactory]: " FACTORY_NAME
FACTORY_NAME=${FACTORY_NAME:-kraft-datafactory}
read -r -p "Storage account [validationblobstorage]: " STORAGE_ACCOUNT
STORAGE_ACCOUNT=${STORAGE_ACCOUNT:-validationblobstorage}
read -r -p "Input container [input]: " INPUT_CONTAINER
INPUT_CONTAINER=${INPUT_CONTAINER:-input}
read -r -p "Output container [output]: " OUTPUT_CONTAINER
OUTPUT_CONTAINER=${OUTPUT_CONTAINER:-output}
read -r -p "Linked service [LS_D5_User01_ADLS]: " LINKED_SERVICE
LINKED_SERVICE=${LINKED_SERVICE:-LS_D5_${PARTICIPANT_ID}_ADLS}
read -r -p "Source dataset [DS_D5_User01_Source]: " SOURCE_DATASET
SOURCE_DATASET=${SOURCE_DATASET:-DS_D5_${PARTICIPANT_ID}_Source}
read -r -p "Sink dataset [DS_D5_User01_Sink]: " SINK_DATASET
SINK_DATASET=${SINK_DATASET:-DS_D5_${PARTICIPANT_ID}_Sink}
read -r -p "Pipeline [PL_D5_User01_WrongPathCopy]: " PIPELINE_NAME
PIPELINE_NAME=${PIPELINE_NAME:-PL_D5_${PARTICIPANT_ID}_WrongPathCopy}
read -r -p "Correct source filename [retail_sales.csv]: " CORRECT_FILE
CORRECT_FILE=${CORRECT_FILE:-retail_sales.csv}
read -r -p "Deliberately incorrect filename [retail_sales_missing.csv]: " WRONG_FILE
WRONG_FILE=${WRONG_FILE:-retail_sales_missing.csv}
read -r -p "Output filename [retail_sales_output.csv]: " OUTPUT_FILE
OUTPUT_FILE=${OUTPUT_FILE:-retail_sales_output.csv}

if [[ ! "$STORAGE_ACCOUNT" =~ ^[a-z0-9]{3,24}$ ]]; then
  echo "ERROR: Storage account name must contain 3-24 lowercase letters/numbers." >&2; exit 1
fi
if [[ "$CORRECT_FILE" == "$WRONG_FILE" ]]; then
  echo "ERROR: Wrong filename must differ from correct filename." >&2; exit 1
fi
for name in "$LINKED_SERVICE" "$SOURCE_DATASET" "$SINK_DATASET" "$PIPELINE_NAME"; do
  if [[ ! "$name" =~ ^[A-Za-z0-9_]+$ ]]; then
    echo "ERROR: Invalid ADF object name: $name" >&2; exit 1
  fi
done

cat <<SUMMARY

=== Confirm configuration ===
Participant ID : $PARTICIPANT_ID
Resource group : $RESOURCE_GROUP
Data Factory   : $FACTORY_NAME
Storage account: $STORAGE_ACCOUNT
Input container: $INPUT_CONTAINER
Output container: $OUTPUT_CONTAINER
Linked service : $LINKED_SERVICE
Source dataset : $SOURCE_DATASET
Sink dataset   : $SINK_DATASET
Pipeline       : $PIPELINE_NAME
Initial wrong path: $INPUT_CONTAINER/$WRONG_FILE
Correct source path: $INPUT_CONTAINER/$CORRECT_FILE
Output path       : $OUTPUT_CONTAINER/$OUTPUT_FILE
SUMMARY
read -r -p "Type CREATE to continue: " CONFIRM
[[ "$CONFIRM" == "CREATE" ]] || { echo "Cancelled."; exit 0; }

if [[ -n "$SUBSCRIPTION_ID" ]]; then
  az account set --subscription "$SUBSCRIPTION_ID"
fi
az account show --query '{Subscription:name,SubscriptionId:id}' --output table
az group show --name "$RESOURCE_GROUP" --output none
az datafactory show --resource-group "$RESOURCE_GROUP" --factory-name "$FACTORY_NAME" --output none
HNS=$(az storage account show --resource-group "$RESOURCE_GROUP" --name "$STORAGE_ACCOUNT" --query isHnsEnabled -o tsv)
[[ "$HNS" == "true" ]] || { echo "ERROR: HNS is not enabled on $STORAGE_ACCOUNT." >&2; exit 1; }

TMP_DIR=$(mktemp -d)
trap 'rm -rf "$TMP_DIR"' EXIT

cat > "$TMP_DIR/linked-service.json" <<JSON
{
  "type": "AzureBlobFS",
  "typeProperties": {
    "url": "https://${STORAGE_ACCOUNT}.dfs.core.windows.net",
    "authenticationType": "ManagedIdentity"
  }
}
JSON

cat > "$TMP_DIR/source-dataset.json" <<JSON
{
  "linkedServiceName": {"referenceName": "${LINKED_SERVICE}", "type": "LinkedServiceReference"},
  "annotations": [],
  "type": "DelimitedText",
  "typeProperties": {
    "location": {"type": "AzureBlobFSLocation", "fileSystem": "${INPUT_CONTAINER}", "fileName": "${WRONG_FILE}"},
    "columnDelimiter": ",",
    "escapeChar": "\\\\",
    "firstRowAsHeader": true,
    "quoteChar": "\\""
  },
  "schema": []
}
JSON

cat > "$TMP_DIR/sink-dataset.json" <<JSON
{
  "linkedServiceName": {"referenceName": "${LINKED_SERVICE}", "type": "LinkedServiceReference"},
  "annotations": [],
  "type": "DelimitedText",
  "typeProperties": {
    "location": {"type": "AzureBlobFSLocation", "fileSystem": "${OUTPUT_CONTAINER}", "fileName": "${OUTPUT_FILE}"},
    "columnDelimiter": ",",
    "escapeChar": "\\\\",
    "firstRowAsHeader": true,
    "quoteChar": "\\""
  },
  "schema": []
}
JSON

cat > "$TMP_DIR/pipeline.json" <<JSON
{
  "activities": [
    {
      "name": "CopyRetailSales",
      "type": "Copy",
      "dependsOn": [],
      "policy": {"timeout": "0.12:00:00", "retry": 0, "retryIntervalInSeconds": 30, "secureOutput": false, "secureInput": false},
      "userProperties": [],
      "typeProperties": {
        "source": {
          "type": "DelimitedTextSource",
          "storeSettings": {"type": "AzureBlobFSReadSettings", "recursive": false, "enablePartitionDiscovery": false},
          "formatSettings": {"type": "DelimitedTextReadSettings"}
        },
        "sink": {
          "type": "DelimitedTextSink",
          "storeSettings": {"type": "AzureBlobFSWriteSettings", "copyBehavior": "PreserveHierarchy"},
          "formatSettings": {"type": "DelimitedTextWriteSettings", "quoteAllText": true, "fileExtension": ".csv"},
          "enableStaging": false
        },
        "enableStaging": false,
        "translator": {"type": "TabularTranslator", "typeConversion": true, "typeConversionSettings": {"allowDataTruncation": true, "treatBooleanAsNumber": false}}
      },
      "inputs": [{"referenceName": "${SOURCE_DATASET}", "type": "DatasetReference"}],
      "outputs": [{"referenceName": "${SINK_DATASET}", "type": "DatasetReference"}]
    }
  ],
  "annotations": []
}
JSON

python -m json.tool "$TMP_DIR/linked-service.json" >/dev/null
python -m json.tool "$TMP_DIR/source-dataset.json" >/dev/null
python -m json.tool "$TMP_DIR/sink-dataset.json" >/dev/null
python -m json.tool "$TMP_DIR/pipeline.json" >/dev/null

echo "Creating/updating managed-identity linked service..."
az datafactory linked-service create --resource-group "$RESOURCE_GROUP" --factory-name "$FACTORY_NAME" --name "$LINKED_SERVICE" --properties "@$TMP_DIR/linked-service.json" --output none
echo "Creating/updating source dataset with intentional wrong filename..."
az datafactory dataset create --resource-group "$RESOURCE_GROUP" --factory-name "$FACTORY_NAME" --name "$SOURCE_DATASET" --properties "@$TMP_DIR/source-dataset.json" --output none
echo "Creating/updating sink dataset..."
az datafactory dataset create --resource-group "$RESOURCE_GROUP" --factory-name "$FACTORY_NAME" --name "$SINK_DATASET" --properties "@$TMP_DIR/sink-dataset.json" --output none
echo "Creating/updating pipeline..."
az datafactory pipeline create --resource-group "$RESOURCE_GROUP" --factory-name "$FACTORY_NAME" --name "$PIPELINE_NAME" --pipeline "@$TMP_DIR/pipeline.json" --output none

cat <<DONE

PIPELINE SETUP COMPLETE
Pipeline: $PIPELINE_NAME
Initial source dataset path: $INPUT_CONTAINER/$WRONG_FILE
Correct path to use after diagnosing: $INPUT_CONTAINER/$CORRECT_FILE

ADF STUDIO STEPS
1. Open Author > Pipelines > $PIPELINE_NAME.
2. Validate and Publish all changes.
3. Run the pipeline using Debug or Add trigger > Trigger now.
4. Open Monitor; inspect the failed CopyRetailSales activity and capture the error.
5. Open Datasets > $SOURCE_DATASET. Change the dataset filename from $WRONG_FILE to $CORRECT_FILE.
6. Validate and Publish all changes.
7. Rerun the SAME pipeline.
8. Verify success, rows read/written, and $OUTPUT_FILE in container $OUTPUT_CONTAINER.

This script does not run the pipeline and does not change RBAC.
DONE
