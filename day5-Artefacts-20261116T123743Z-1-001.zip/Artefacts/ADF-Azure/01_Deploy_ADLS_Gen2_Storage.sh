#!/usr/bin/env bash
set -euo pipefail

# Day 5 | DA-D5-503 | Scenario 1: ADLS Gen2 storage and data preparation
# Run in Azure Cloud Shell Bash. This script creates/reuses the storage account,
# creates input/output containers, and uploads the sample CSV from Cloud Shell.

echo
echo "=== DA-D5-503 | Scenario 1: Storage and Data Preparation ==="
echo "Prerequisite: upload retail_sales.csv to your Cloud Shell home directory."
echo

read -r -p "Azure subscription ID (blank = current subscription): " SUBSCRIPTION_ID
read -r -p "Resource group [Kraft-Cadet]: " RESOURCE_GROUP
RESOURCE_GROUP=${RESOURCE_GROUP:-Kraft-Cadet}
read -r -p "Azure region [eastus]: " LOCATION
LOCATION=${LOCATION:-eastus}
read -r -p "Storage account name [validationblobstorage]: " STORAGE_ACCOUNT
STORAGE_ACCOUNT=${STORAGE_ACCOUNT:-validationblobstorage}
read -r -p "Input container [input]: " INPUT_CONTAINER
INPUT_CONTAINER=${INPUT_CONTAINER:-input}
read -r -p "Output container [output]: " OUTPUT_CONTAINER
OUTPUT_CONTAINER=${OUTPUT_CONTAINER:-output}
read -r -p "Local CSV path [$HOME/retail_sales.csv]: " CSV_PATH
CSV_PATH=${CSV_PATH:-$HOME/retail_sales.csv}
read -r -p "Blob filename [retail_sales.csv]: " BLOB_NAME
BLOB_NAME=${BLOB_NAME:-retail_sales.csv}

if [[ ! "$STORAGE_ACCOUNT" =~ ^[a-z0-9]{3,24}$ ]]; then
  echo "ERROR: Storage account name must contain 3-24 lowercase letters/numbers." >&2; exit 1
fi
for container in "$INPUT_CONTAINER" "$OUTPUT_CONTAINER"; do
  if [[ ! "$container" =~ ^[a-z0-9][a-z0-9-]{1,61}[a-z0-9]$ ]]; then
    echo "ERROR: Invalid container name: $container" >&2; exit 1
  fi
done
if [[ ! -f "$CSV_PATH" ]]; then
  echo "ERROR: CSV not found: $CSV_PATH"
  echo "Upload retail_sales.csv to Cloud Shell home, then rerun this script."
  exit 1
fi

cat <<SUMMARY

=== Confirm configuration ===
Subscription ID : ${SUBSCRIPTION_ID:-current}
Resource group  : $RESOURCE_GROUP
Region          : $LOCATION
Storage account : $STORAGE_ACCOUNT
Hierarchical namespace: enabled
Input container : $INPUT_CONTAINER
Output container: $OUTPUT_CONTAINER
Local CSV       : $CSV_PATH
Uploaded name   : $BLOB_NAME
SUMMARY
read -r -p "Type CREATE to continue: " CONFIRM
[[ "$CONFIRM" == "CREATE" ]] || { echo "Cancelled."; exit 0; }

if [[ -n "$SUBSCRIPTION_ID" ]]; then
  az account set --subscription "$SUBSCRIPTION_ID"
fi
az account show --query '{Subscription:name,SubscriptionId:id}' --output table
az group show --name "$RESOURCE_GROUP" --output none

if az storage account show --resource-group "$RESOURCE_GROUP" --name "$STORAGE_ACCOUNT" --output none 2>/dev/null; then
  echo "Storage account exists; checking HNS..."
  HNS=$(az storage account show --resource-group "$RESOURCE_GROUP" --name "$STORAGE_ACCOUNT" --query isHnsEnabled -o tsv)
  if [[ "$HNS" != "true" ]]; then
    echo "ERROR: Existing storage account does not have hierarchical namespace enabled." >&2
    exit 1
  fi
else
  echo "Creating ADLS Gen2 storage account..."
  az storage account create \
    --resource-group "$RESOURCE_GROUP" \
    --name "$STORAGE_ACCOUNT" \
    --location "$LOCATION" \
    --sku Standard_LRS \
    --kind StorageV2 \
    --enable-hierarchical-namespace true \
    --allow-blob-public-access false \
    --output none
fi

ACCOUNT_KEY=$(az storage account keys list --resource-group "$RESOURCE_GROUP" --account-name "$STORAGE_ACCOUNT" --query '[0].value' -o tsv)
az storage container create --name "$INPUT_CONTAINER" --account-name "$STORAGE_ACCOUNT" --account-key "$ACCOUNT_KEY" --output none
az storage container create --name "$OUTPUT_CONTAINER" --account-name "$STORAGE_ACCOUNT" --account-key "$ACCOUNT_KEY" --output none
az storage blob upload \
  --account-name "$STORAGE_ACCOUNT" \
  --account-key "$ACCOUNT_KEY" \
  --container-name "$INPUT_CONTAINER" \
  --name "$BLOB_NAME" \
  --file "$CSV_PATH" \
  --overwrite true \
  --output none
unset ACCOUNT_KEY

echo
echo "STORAGE SETUP COMPLETE"
echo "Storage account : $STORAGE_ACCOUNT"
echo "HNS enabled     : true"
echo "Source blob     : $INPUT_CONTAINER/$BLOB_NAME"
echo "Output container: $OUTPUT_CONTAINER"
echo
echo "NEXT: run 02_Create_Wrong_Path_Pipeline.sh"
