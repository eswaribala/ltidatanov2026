"""Kafka default partitioner for keyed records: toPositive(murmur2(key)) % numPartitions."""
def murmur2(data: bytes) -> int:
    length = len(data); seed = 0x9747b28c; m = 0x5bd1e995; r = 24
    h = (seed ^ length) & 0xffffffff
    l4 = length // 4
    for i in range(l4):
        i4 = i * 4
        k = (data[i4] & 0xff) + ((data[i4+1] & 0xff) << 8) + ((data[i4+2] & 0xff) << 16) + ((data[i4+3] & 0xff) << 24)
        k = (k * m) & 0xffffffff; k ^= k >> r; k = (k * m) & 0xffffffff
        h = (h * m) & 0xffffffff; h ^= k
    rem = length % 4; base = l4 * 4
    if rem == 3: h ^= (data[base+2] & 0xff) << 16
    if rem >= 2: h ^= (data[base+1] & 0xff) << 8
    if rem >= 1:
        h ^= data[base] & 0xff; h = (h * m) & 0xffffffff
    h ^= h >> 13; h = (h * m) & 0xffffffff; h ^= h >> 15
    return h - (1 << 32) if h & 0x80000000 else h
def partition(key: str, n: int) -> int:
    return (murmur2(key.encode()) & 0x7fffffff) % n
if __name__ == "__main__":
    cases = {b"21": -973932308, b"foobar": -790332482, b"a-little-bit-long-string": -985981536,
             b"a-little-bit-longer-string": -1486304829,
             b"lkjh234lh9fiuh90y23oiuhsafujhadof229phr9h19h89h8": -58897971, b"abc": 479470107}
    for k, v in cases.items(): print(k, murmur2(k), v, "OK" if murmur2(k) == v else "MISMATCH")
