Day 4 Starter Files - Apache Kafka Operations & Streaming Platforms
===================================================================
DEPLOY to every learner VM as /labfiles/day4  (docker-compose.yml, k, data/, murmur2.py)

VM REQUIREMENTS
  * Linux with Docker Engine and Docker Compose v2 (docker compose version), user in the docker group
  * 4 GB RAM free for three Kafka containers
  * Pre-pull the image before class (saves 2-5 minutes per learner):  docker pull apache/kafka:4.3.1

FILES
  docker-compose.yml   3-node KRaft cluster (kafka-1/2/3), RF 3 for internal topics
  k                    wrapper: ./k <tool>.sh [args] runs a Kafka CLI tool inside kafka-1
  data/keyed_orders.txt     12 keyed orders (Lab 2)
  data/skewed_orders.txt    2,000 orders, 80% for STORE-001 (Lab 5)
  data/salted_orders.txt    same orders with the hot key salted 32 ways (Lab 5)
  murmur2.py           Kafka's default partitioner in Python (verified against Kafka test vectors)
                       python3 -c "from murmur2 import partition; print(partition('STORE-001', 6))"

EXPECTED (exact, from murmur2): keyed_orders on 6 partitions -> per partition 0,4,2,0,2,4
  skewed  -> 63,1642,106,21,42,126      salted -> 162,244,304,473,391,426

Labs 1-5 run in order on the same cluster. Clean-up at the end of the day:  docker compose down -v
