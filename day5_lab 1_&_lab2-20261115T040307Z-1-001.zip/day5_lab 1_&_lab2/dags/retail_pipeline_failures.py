from datetime import datetime, timedelta

from airflow import DAG
from airflow.models.param import Param
from airflow.operators.python import PythonOperator
from airflow.operators.bash import BashOperator
from airflow.utils.trigger_rule import TriggerRule


def flaky_extract():
    from airflow.operators.python import get_current_context

    context = get_current_context()
    attempt = context["ti"].try_number

    if attempt == 1:
        raise RuntimeError("ERROR: sales API timed out")

    print("Sales API recovered on retry")
    print("rows_extracted=1200")


def validate_data():
    from airflow.operators.python import get_current_context

    context = get_current_context()
    inject_failure = context["params"]["inject_failure"]

    print("Validating 1200 rows")

    if inject_failure:
        raise ValueError(
            "ERROR: 37 rows have a NULL store_id - validation failed"
        )

    print("Data validation passed")


with DAG(
    dag_id="retail_pipeline_failures",
    description="Retail pipeline retry, trigger-rule and failure analysis",
    schedule=None,
    start_date=datetime(2026, 1, 1),
    catchup=False,
    default_args={
        "owner": "airflow",
        "retries": 0,
    },
    params={
        "inject_failure": Param(False, type="boolean"),
    },
    tags=["retail", "failure-analysis"],
) as dag:

    flaky_extract_task = PythonOperator(
        task_id="flaky_extract",
        python_callable=flaky_extract,
        retries=2,
        retry_delay=timedelta(seconds=15),
    )

    validate_data_task = PythonOperator(
        task_id="validate_data",
        python_callable=validate_data,
        retries=0,
    )

    load_warehouse_task = BashOperator(
        task_id="load_warehouse",
        bash_command="echo 'Loading validated retail data into warehouse'",
    )

    alert_on_failure_task = BashOperator(
        task_id="alert_on_failure",
        bash_command="echo 'ALERT: Retail pipeline failure detected'",
        trigger_rule=TriggerRule.ONE_FAILED,
    )

    cleanup_temp_files_task = BashOperator(
        task_id="cleanup_temp_files",
        bash_command="echo 'Cleaning temporary retail pipeline files'",
        trigger_rule=TriggerRule.ALL_DONE,
    )

    flaky_extract_task >> validate_data_task
    validate_data_task >> load_warehouse_task
    [load_warehouse_task, validate_data_task] >> alert_on_failure_task
    [load_warehouse_task, alert_on_failure_task] >> cleanup_temp_files_task
