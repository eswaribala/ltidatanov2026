from datetime import datetime, timedelta
from pathlib import Path
import csv
from airflow import DAG
from airflow.exceptions import AirflowException, AirflowSensorTimeout
from airflow.sensors.python import PythonSensor
from airflow.operators.python import PythonOperator
from airflow.operators.empty import EmptyOperator
from airflow.utils.trigger_rule import TriggerRule

class RetryablePythonSensor(PythonSensor):
    def execute(self, context):
        try:
            return super().execute(context)
        except AirflowSensorTimeout as exc:
            raise AirflowException(
                f"ERP file sensor timed out; retrying: {exc}"
            ) from exc


DATA = Path("/opt/airflow/dags/data")

def file_exists(filename):
    return (DATA / filename).is_file()

def pos_file_ready(**context):
    run_date = context["dag_run"].conf.get("run_date", "2026-03-15")
    return file_exists(f"pos_{run_date}.csv")

def erp_file_ready(**context):
    run_date = context["dag_run"].conf.get("run_date", "2026-03-15")
    return file_exists(f"erp_{run_date}.csv")

def reconcile(run_date):
    pos_file = DATA / f"pos_{run_date}.csv"
    erp_file = DATA / f"erp_{run_date}.csv"

    def load(path):
        with path.open() as f:
            rows = list(csv.DictReader(f))
        total = sum(float(r["amount"]) for r in rows)
        return rows, total

    pos, pos_total = load(pos_file)
    erp, erp_total = load(erp_file)

    pos_ids = {r["transaction_id"] for r in pos}
    erp_ids = {r["transaction_id"] for r in erp}
    missing = sorted(pos_ids - erp_ids)

    if missing:
        print(f"Missing in ERP: {', '.join(missing)}")

    if len(pos) != len(erp) or round(pos_total, 2) != round(erp_total, 2):
        raise ValueError(
            f"ERROR: reconciliation mismatch for {run_date}: "
            f"POS {len(pos)}/{pos_total:.2f} vs ERP {len(erp)}/{erp_total:.2f}"
        )

    print(
        f"Reconciliation OK for {run_date} | "
        f"POS: {len(pos)} transactions, ERP: {len(erp)} transactions, "
        f"ERP: {len(erp)} transactions total {erp_total:.2f}"
    )

def publish():
    print("Reconciliation report published.")

def notify():
    print("Finance operations notified about reconciliation failure.")

with DAG(
    dag_id="retail_eod_reconciliation",
    start_date=datetime(2026, 3, 1),
    schedule=None,
    catchup=False,
    default_args={
        "owner": "finance-ops",
        "retries": 0,
        "retry_delay": timedelta(seconds=20),
    },
    tags=["day7", "lab5", "reconciliation"],
) as dag:

    wait_for_pos_file = PythonSensor(
        task_id="wait_for_pos_file",
        python_callable=pos_file_ready,
        poke_interval=5,
        timeout=60,
        mode="poke",
    )

    wait_for_erp_file = RetryablePythonSensor(
        task_id="wait_for_erp_file",
        python_callable=erp_file_ready,
        poke_interval=20,
        timeout=45,
        retries=2,
        mode="poke",
    )

    reconcile_task = PythonOperator(
        task_id="reconcile",
        python_callable=lambda **context: reconcile(
            context["dag_run"].conf.get("run_date", "2026-03-15")
        ),
    )

    publish_report = PythonOperator(
        task_id="publish_report",
        python_callable=publish,
    )

    notify_on_failure = PythonOperator(
        task_id="notify_on_failure",
        python_callable=notify,
        trigger_rule=TriggerRule.ONE_FAILED,
    )

    [wait_for_pos_file, wait_for_erp_file] >> reconcile_task
    reconcile_task >> publish_report
    [wait_for_pos_file, wait_for_erp_file, reconcile_task] >> notify_on_failure
