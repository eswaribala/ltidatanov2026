from datetime import datetime, timedelta

from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.operators.bash import BashOperator


def extract_sales():
    from airflow.operators.python import get_current_context

    context = get_current_context()
    run_id = context["run_id"]

    print(f"Extracting sales for run {run_id}")
    print("rows_extracted=1200")


def transform_orders():
    print("Transforming retail orders")


def transform_customers():
    print("Transforming retail customers")


def load_warehouse():
    print("Loading data into the warehouse")


def publish_report():
    print("Publishing the retail sales report")


default_args = {
    "owner": "airflow",
    "retries": 1,
    "retry_delay": timedelta(minutes=2),
}

with DAG(
    dag_id="retail_daily_sales",
    default_args=default_args,
    description="Daily retail sales processing pipeline",
    schedule="0 6 * * *",
    start_date=datetime(2026, 1, 1),
    catchup=False,
    tags=["retail", "sales"],
) as dag:

    extract_sales_task = PythonOperator(
        task_id="extract_sales",
        python_callable=extract_sales,
    )

    transform_orders_task = PythonOperator(
        task_id="transform_orders",
        python_callable=transform_orders,
    )

    transform_customers_task = PythonOperator(
        task_id="transform_customers",
        python_callable=transform_customers,
    )

    load_warehouse_task = BashOperator(
        task_id="load_warehouse",
        bash_command="echo 'Loading retail data into warehouse'",
    )

    publish_report_task = PythonOperator(
        task_id="publish_report",
        python_callable=publish_report,
    )

    extract_sales_task >> transform_orders_task
    transform_orders_task >> transform_customers_task
    transform_customers_task >> load_warehouse_task
    load_warehouse_task >> publish_report_task

    notify_finance = BashOperator(
        task_id="notify_finance",
        bash_command='echo "Finance notified for run {{ run_id }}"',
    )

    load_warehouse_task >> notify_finance

