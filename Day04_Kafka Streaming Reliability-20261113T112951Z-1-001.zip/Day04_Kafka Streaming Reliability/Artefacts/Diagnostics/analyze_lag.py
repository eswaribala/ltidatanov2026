import csv,sys
from collections import defaultdict
path=sys.argv[1] if len(sys.argv)>1 else '04_Datasets/kafka_lag_snapshots.csv'
rows=list(csv.DictReader(open(path,newline='',encoding='utf8')))
by=defaultdict(list)
for r in rows:
 expected=int(r['log_end_offset'])-int(r['committed_offset'])
 assert expected==int(r['lag']),f"Lag mismatch: {r}"
 by[r['partition']].append(r)
for p,records in sorted(by.items()):
 peak=max(records,key=lambda x:int(x['lag']))
 print(f"partition={p} peak_lag={peak['lag']} at={peak['timestamp_utc']} first={records[0]['lag']} last={records[-1]['lag']} status_at_peak={peak['consumer_status']}")
