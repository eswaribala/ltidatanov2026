# Kafka throughput and reliability review

| Setting | Potential benefit | Trade-off / caution |
|---|---|---|
| `acks=all` | Durability acknowledgement from in-sync replicas | Increased latency; on RF=1 it is not high availability |
| `enable_idempotence=true` | Reduces duplicate writes on producer retries | Does not make downstream side effects exactly-once |
| `linger_ms` | Batching efficiency | Adds per-batch latency |
| `batch_size` | Higher batch throughput | Increased producer memory |
| `compression_type` | Lower network payload | CPU overhead |
| Consumer concurrency | Parallel processing | Effective parallelism capped by partition count per group |
| Partition key choice | Distribution of traffic | Changing key semantics affects order guarantees |

Always capture baseline latency, throughput, error count, and lag before/after changes.
