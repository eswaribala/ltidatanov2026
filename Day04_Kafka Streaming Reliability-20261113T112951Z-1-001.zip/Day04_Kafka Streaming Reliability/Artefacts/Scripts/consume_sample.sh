#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
docker compose exec -T broker /opt/kafka/bin/kafka-console-consumer.sh --bootstrap-server localhost:9092 --topic day4_orders --from-beginning --max-messages 5 --timeout-ms 15000
