import argparse,json
from kafka import KafkaProducer
p=argparse.ArgumentParser();p.add_argument('--bootstrap',default='localhost:29092');p.add_argument('--topic',default='day4_orders');p.add_argument('--file',required=True);p.add_argument('--start',type=int,default=0);p.add_argument('--limit',type=int,default=100)
a=p.parse_args()
producer=KafkaProducer(bootstrap_servers=a.bootstrap,acks='all',retries=5,enable_idempotence=True,value_serializer=lambda x:json.dumps(x).encode('utf-8'),key_serializer=lambda x:x.encode('utf-8'))
count=0
with open(a.file,encoding='utf8') as f:
 for idx,line in enumerate(f):
  if idx<a.start:continue
  if count>=a.limit:break
  event=json.loads(line)
  producer.send(a.topic,key=event['order_id'],value=event).get(timeout=15)
  count+=1
producer.flush();producer.close();print(f'Sent {count} events to {a.topic}')
