#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
K="docker compose exec -T broker /opt/kafka/bin"
for attempt in $(seq 1 30); do
  if docker compose exec -T broker /opt/kafka/bin/kafka-topics.sh --bootstrap-server localhost:9092 --list >/dev/null 2>&1; then break; fi
  sleep 2
done
docker compose exec -T broker /opt/kafka/bin/kafka-topics.sh --bootstrap-server localhost:9092 --create --if-not-exists --topic day4_orders --partitions 3 --replication-factor 1
docker compose exec -T broker /opt/kafka/bin/kafka-topics.sh --bootstrap-server localhost:9092 --describe --topic day4_orders
