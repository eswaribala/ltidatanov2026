import argparse,json
from kafka import KafkaConsumer
p=argparse.ArgumentParser();p.add_argument('--bootstrap',default='localhost:29092');p.add_argument('--topic',default='day4_orders');p.add_argument('--group',default='day4_analytics');p.add_argument('--max-messages',type=int,default=50)
a=p.parse_args()
consumer=KafkaConsumer(a.topic,bootstrap_servers=a.bootstrap,group_id=a.group,enable_auto_commit=False,auto_offset_reset='earliest',consumer_timeout_ms=20000,value_deserializer=lambda b:json.loads(b.decode('utf8')))
count=0
try:
 for msg in consumer:
  print(f'partition={msg.partition} offset={msg.offset} event_id={msg.value["event_id"]}')
  consumer.commit();count+=1
  if count>=a.max_messages:break
finally:consumer.close()
print(f'Consumed and committed {count} messages')
