select
    c.customer_id,
    c.customer_name,
    c.city,
    count(distinct f.order_id) as order_count,
    coalesce(sum(f.amount_paid), 0) as lifetime_value
from {{ ref('stg_customers') }} c
left join {{ ref('fct_orders') }} f
    on c.customer_id = f.customer_id
group by
    c.customer_id,
    c.customer_name,
    c.city
