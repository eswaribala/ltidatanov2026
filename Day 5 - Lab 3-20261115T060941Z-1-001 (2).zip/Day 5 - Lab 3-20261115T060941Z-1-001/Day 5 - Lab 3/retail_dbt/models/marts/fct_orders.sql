select
    o.order_id,
    o.customer_id,
    o.order_date,
    o.status,
    coalesce(sum(p.amount), 0) as amount_paid
from {{ ref('stg_orders') }} o
left join {{ ref('stg_payments') }} p
    on o.order_id = p.order_id
group by
    o.order_id,
    o.customer_id,
    o.order_date,
    o.status
