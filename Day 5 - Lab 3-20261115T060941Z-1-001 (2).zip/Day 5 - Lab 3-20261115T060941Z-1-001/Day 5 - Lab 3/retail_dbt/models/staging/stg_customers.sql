select
    cast(customer_id as integer) as customer_id,
    trim(customer_name) as customer_name,
    trim(city) as city
from {{ ref('raw_customers') }}
