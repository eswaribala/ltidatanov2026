# Databricks notebook source
# Task publish_report: refresh gold_store_daily for run_date and check row counts end to end
dbutils.widgets.text("run_date", "2026-03-14")
run_date = dbutils.widgets.get("run_date")
import re
me = spark.sql("SELECT current_user()").first()[0]
SCHEMA = "day7_" + re.sub(r"[^a-z0-9]", "_", me.split("@")[0].lower())
spark.sql("USE CATALOG workspace")   # Free Edition default catalog
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {SCHEMA}")
spark.sql(f"USE SCHEMA {SCHEMA}")

spark.sql("""CREATE TABLE IF NOT EXISTS gold_store_daily
             (order_date DATE, store_id STRING, orders BIGINT, revenue DECIMAL(18,2))""")
spark.sql(f"DELETE FROM gold_store_daily WHERE order_date = DATE'{run_date}'")
spark.sql(f"""
INSERT INTO gold_store_daily
SELECT order_date, store_id, COUNT(*), SUM(amount) FROM silver_orders
WHERE order_date = DATE'{run_date}' GROUP BY order_date, store_id
""")
r = spark.sql(f"""SELECT COUNT(*) AS stores, SUM(orders) AS orders, SUM(revenue) AS revenue
                  FROM gold_store_daily WHERE order_date = DATE'{run_date}'""").first()
staged = spark.table("staging_orders").count()
assert r.orders == staged, f"Row count mismatch: staging {staged} vs gold {r.orders}"
print(f"publish_report: {run_date}  stores={r.stores}  orders={r.orders}  revenue={r.revenue}")
