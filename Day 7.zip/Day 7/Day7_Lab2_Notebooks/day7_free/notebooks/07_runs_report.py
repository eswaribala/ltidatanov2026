# Databricks notebook source
# MAGIC %md
# MAGIC # Day 7 Lab 2 - Job runs report (what a support engineer checks every morning)
# MAGIC Lists the recent runs of YOUR orders-daily job with each task's result, duration and error.

# COMMAND ----------

import re, datetime
from databricks.sdk import WorkspaceClient
me = spark.sql("SELECT current_user()").first()[0]
SCHEMA = "day7_" + re.sub(r"[^a-z0-9]", "_", me.split("@")[0].lower())
w = WorkspaceClient()
job = next(iter(w.jobs.list(name=f"{SCHEMA}-orders-daily")))

def state_of(r):
    """Works with both the newer status field and the older state field of the SDK."""
    st = getattr(r, "status", None)
    if st is not None and getattr(st, "state", None) is not None:
        code = st.termination_details.code.value if st.termination_details and st.termination_details.code else ""
        return st.state.value, code
    s = getattr(r, "state", None)
    life = s.life_cycle_state.value if s and s.life_cycle_state else "?"
    res = s.result_state.value if s and s.result_state else ""
    return life, res

def ts(ms):
    return datetime.datetime.fromtimestamp(ms / 1000).strftime("%H:%M:%S") if ms else "-"

for run in w.jobs.list_runs(job_id=job.job_id, expand_tasks=True, limit=10):
    params = {p.name: p.value for p in (run.job_parameters or [])}
    state, term = state_of(run)
    print(f"RUN {run.run_id}  run_date={params.get('run_date')}  start={ts(run.start_time)}  state={state} {term}")
    for t in sorted(run.tasks or [], key=lambda t: t.start_time or 0):
        tstate, tterm = state_of(t)
        secs = round(((t.end_time or 0) - (t.start_time or 0)) / 1000) if t.end_time and t.start_time else "-"
        line = f"    {t.task_key:18s} attempt={t.attempt_number}  {tstate:10s} {tterm:16s} {secs}s"
        if tterm and tterm not in ("SUCCESS",):
            try:
                out = w.jobs.get_run_output(t.run_id)
                if out.error:
                    line += "\n        error: " + out.error.splitlines()[0][:160]
            except Exception as e:
                line += f"\n        (output not available: {type(e).__name__})"
        print(line)
