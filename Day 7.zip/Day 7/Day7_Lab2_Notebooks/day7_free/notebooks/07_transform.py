# Databricks notebook source
# Task transform_orders: typed, de-duplicated silver rows for run_date (re-runnable: delete + insert)
dbutils.widgets.text("run_date", "2026-03-14")
run_date = dbutils.widgets.get("run_date")
import re
me = spark.sql("SELECT current_user()").first()[0]
SCHEMA = "day7_" + re.sub(r"[^a-z0-9]", "_", me.split("@")[0].lower())
spark.sql("USE CATALOG workspace")   # Free Edition default catalog
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {SCHEMA}")
spark.sql(f"USE SCHEMA {SCHEMA}")

AMOUNT_COLUMN = "amount"
# AMOUNT_COLUMN = "order_amount" if "order_amount" in spark.table("staging_orders").columns else "amount"   # HOTFIX (Lab 2 Task 3)

spark.sql("""CREATE TABLE IF NOT EXISTS silver_orders
             (order_id STRING, store_id STRING, amount DECIMAL(10,2), order_ts TIMESTAMP, order_date DATE)""")
spark.sql(f"DELETE FROM silver_orders WHERE order_date = DATE'{run_date}'")
spark.sql(f"""
INSERT INTO silver_orders
SELECT order_id, store_id, CAST({AMOUNT_COLUMN} AS DECIMAL(10,2)), CAST(order_ts AS TIMESTAMP), DATE'{run_date}'
FROM staging_orders
""")
n = spark.sql(f"SELECT COUNT(*) FROM silver_orders WHERE order_date = DATE'{run_date}'").first()[0]
print(f"transform_orders: {n} rows written to silver_orders for {run_date} (amount column used: {AMOUNT_COLUMN})")
