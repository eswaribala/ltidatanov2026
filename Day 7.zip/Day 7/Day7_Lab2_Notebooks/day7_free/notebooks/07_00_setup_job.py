# Databricks notebook source
# MAGIC %md
# MAGIC # Day 7 Lab 2 - Set up the orders-daily job
# MAGIC Databricks Free Edition: import the day7-labs notebooks into Workspace > Home > day7-labs,
# MAGIC attach this notebook to **Serverless**, then Run all.
# MAGIC Creates: schema workspace.day7_<you>, volume landing with two daily files, and the 3-task SERVERLESS job <schema>-orders-daily.

# COMMAND ----------

# Cell 1 - schema, volume and the two landing files (2026-03-15 arrives with a renamed column)
import re
me = spark.sql("SELECT current_user()").first()[0]
SCHEMA = "day7_" + re.sub(r"[^a-z0-9]", "_", me.split("@")[0].lower())
spark.sql("USE CATALOG workspace")   # Free Edition default catalog
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {SCHEMA}")
spark.sql(f"USE SCHEMA {SCHEMA}")
spark.sql("CREATE VOLUME IF NOT EXISTS landing")
base = f"/Volumes/workspace/{SCHEMA}/landing"

def write_day(day, n, amount_header):
    path = f"{base}/orders_2026-03-{day}.csv"
    with open(path, "w") as f:
        f.write(f"order_id,store_id,{amount_header},order_ts\n")
        for i in range(n):
            amount = ((i * 37) % 500 + 1) * 1.25
            f.write(f"{day}-{i:05d},S{i % 10 + 1:02d},{amount:.2f},2026-03-{day} {i // 60:02d}:{i % 60:02d}:00\n")
    return path

print(write_day(14, 1000, "amount"))
print(write_day(15, 1200, "order_amount"))     # upstream renamed the column - nobody told the data team
for t in ("staging_orders", "silver_orders", "gold_store_daily"):
    spark.sql(f"DROP TABLE IF EXISTS {t}")
print("Working in: workspace." + SCHEMA)

# COMMAND ----------

# Cell 2 - create (or re-create) the job with three notebook tasks on SERVERLESS job compute
#          (no cluster is specified, so each notebook task runs on serverless)
from databricks.sdk import WorkspaceClient
from databricks.sdk.service import jobs

w = WorkspaceClient()
folder = f"/Users/{w.current_user.me().user_name}/day7-labs"      # where you imported the notebooks
for nb in ("07_ingest", "07_transform", "07_report"):
    w.workspace.get_status(f"{folder}/{nb}")                        # fails clearly if a notebook is missing
job_name = f"{SCHEMA}-orders-daily"

for j in w.jobs.list(name=job_name):
    w.jobs.delete(j.job_id)

def task(key, notebook, deps):
    return jobs.Task(task_key=key,
                     notebook_task=jobs.NotebookTask(notebook_path=f"{folder}/{notebook}"),
                     depends_on=[jobs.TaskDependency(task_key=d) for d in deps])

job = w.jobs.create(
    name=job_name,
    max_concurrent_runs=1,
    parameters=[jobs.JobParameterDefinition(name="run_date", default="2026-03-14")],
    tasks=[task("ingest_orders", "07_ingest", []),
           task("transform_orders", "07_transform", ["ingest_orders"]),
           task("publish_report", "07_report", ["transform_orders"])])
print("Job created:", job_name, " job_id:", job.job_id, " compute: serverless")
print("Open: Jobs & Pipelines > Jobs >", job_name)
