# Databricks notebook source
# Task ingest_orders: load the landing file for run_date into staging_orders (all columns as text, schema may change)
dbutils.widgets.text("run_date", "2026-03-14")
run_date = dbutils.widgets.get("run_date")
import re
me = spark.sql("SELECT current_user()").first()[0]
SCHEMA = "day7_" + re.sub(r"[^a-z0-9]", "_", me.split("@")[0].lower())
spark.sql("USE CATALOG workspace")   # Free Edition default catalog
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {SCHEMA}")
spark.sql(f"USE SCHEMA {SCHEMA}")

path = f"/Volumes/workspace/{SCHEMA}/landing/orders_{run_date}.csv"
df = spark.read.option("header", True).csv(path)
df.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable("staging_orders")
print(f"ingest_orders: {df.count()} rows from {path}; columns = {df.columns}")
