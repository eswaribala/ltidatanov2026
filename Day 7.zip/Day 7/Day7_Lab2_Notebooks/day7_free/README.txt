Day 7 Lab 2 - Databricks FREE EDITION (serverless) version
===========================================================
SET-UP (each learner, about 3 minutes)
  1. Sign in to Databricks Free Edition.
  2. Workspace > Home > Create > Folder named exactly  day7-labs  > Import the five .py files in notebooks/.
  3. Open 07_00_setup_job > compute selector > Serverless > Run all.
     Creates workspace.day7_<you> (volume landing with two CSV files) and the job day7_<you>-orders-daily,
     whose three notebook tasks run on SERVERLESS job compute (no cluster is specified).

WHAT CHANGED FROM THE CLASSIC-CLUSTER VERSION
  * Catalog workspace (not training); volume path /Volumes/workspace/day7_<you>/landing
  * Notebooks live in Home/day7-labs (no Shared folder, no clone step); the job points to that folder
  * Job tasks: serverless compute; no Spark UI (use the task output and Query profile)
  * Free Edition limits: max 5 concurrent job tasks; daily compute quota

EXPECTED VALUES (exact, unchanged)
  2026-03-14 run: 1000 rows, 10 stores, revenue 313125.00 (top S08 31875.00)
  2026-03-15 run: transform_orders fails [UNRESOLVED_COLUMN.WITH_SUGGESTION] `amount` (did you mean `order_amount`)
  after HOTFIX + Repair run: 1200 rows, 10 stores, revenue 376250.00 (top S08 38750.00)

CLEAN-UP after sign-off: delete the job; DROP SCHEMA workspace.day7_<you> CASCADE;
