import argparse
import csv
from collections import Counter, defaultdict
from pathlib import Path

CSV_FILE = Path(__file__).resolve().parent / "alerts_2026-03-16.csv"

def load_alerts():
    with CSV_FILE.open(newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))

def dedup(alerts):
    groups = defaultdict(list)
    for row in alerts:
        key = (row["source"], row["service"], row["check"])
        groups[key].append(row)

    ordered = sorted(
        groups.items(),
        key=lambda item: min(
            (row["timestamp"], row["alert_id"]) for row in item[1]
        )
    )

    print(f"dedup: {len(ordered)} groups, ending with {len(alerts)} alerts -> "
          f"{len(ordered)} distinct alert groups")

    for index, ((source, service, check), rows) in enumerate(ordered, start=1):
        rows.sort(key=lambda r: (r["timestamp"], r["alert_id"]))
        worst = min(
            rows,
            key=lambda r: {"critical": 0, "warning": 1, "info": 2}.get(
                r["severity"], 3
            )
        )
        print(
            f"group {index} {source} {service} {check} "
            f"count {len(rows)}, first {rows[0]['timestamp']}, "
            f"last {rows[-1]['timestamp']}, worst {worst['severity']}, "
            f"last_status {rows[-1]['status']}"
        )

def service_report(alerts, service):
    rows = [r for r in alerts if r["service"] == service]
    print(f"service: {service} {len(rows)} alerts")
    for row in sorted(rows, key=lambda r: (r["timestamp"], r["alert_id"])):
        print(
            f"{row['alert_id']} {row['timestamp']} {row['source']} "
            f"{row['check']} {row['severity']} {row['status']}: "
            f"{row['message']}"
        )

def summary(alerts):
    for source in sorted({r["source"] for r in alerts}):
        rows = [r for r in alerts if r["source"] == source]
        c = Counter(r["severity"] for r in rows)
        print(f"{source} {c['critical']}/{c['warning']}/{c['info']}={len(rows)}")
    print("TOTAL", dict(Counter(r["severity"] for r in alerts)))
    print("status:", dict(Counter(r["status"] for r in alerts)))

def timeline(alerts, source=None):
    rows = [r for r in alerts if source is None or r["source"] == source]
    rows.sort(key=lambda r: (r["timestamp"], r["alert_id"]))
    if not rows:
        print("No alerts found.")
        return
    print(f"timeline: {rows[0]['alert_id']} {rows[0]['timestamp']} -- "
          f"{rows[-1]['alert_id']} {rows[-1]['timestamp']}")
    if source:
        print(f"{source}: {len(rows)} lines, services "
              + ", ".join(sorted({r['service'] for r in rows})))
    else:
        for r in rows:
            print(f"{r['alert_id']} {r['timestamp']} {r['source']} "
                  f"{r['severity']} {r['status']} {r['service']} "
                  f"{r['check']}: {r['message']}")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=["summary", "timeline", "dedup", "service"])
    parser.add_argument("--source")
    parser.add_argument("service_name", nargs="?")
    args = parser.parse_args()

    alerts = load_alerts()
    if args.command == "summary":
        summary(alerts)
    elif args.command == "timeline":
        timeline(alerts, args.source)
    elif args.command == "dedup":
        dedup(alerts)
    elif args.command == "service":
        if not args.service_name:
            parser.error("service requires a service name")
        service_report(alerts, args.service_name)

if __name__ == "__main__":
    main()
