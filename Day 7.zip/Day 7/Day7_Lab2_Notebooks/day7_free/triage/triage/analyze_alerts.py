import csv
import json
from collections import Counter
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
INPUT_FILE = BASE_DIR / "alerts_2026-03-16.csv"
OUTPUT_FILE = BASE_DIR / "alert_summary.json"

with INPUT_FILE.open("r", newline="", encoding="utf-8") as file:
    alerts = list(csv.DictReader(file))

summary = {
    "total_alerts": len(alerts),
    "by_source": dict(sorted(Counter(row["source"] for row in alerts).items())),
    "by_severity": dict(sorted(Counter(row["severity"] for row in alerts).items())),
    "by_status": dict(sorted(Counter(row["status"] for row in alerts).items())),
    "critical_firing_alerts": sum(
        1 for row in alerts
        if row["severity"] == "critical" and row["status"] == "firing"
    ),
}

with OUTPUT_FILE.open("w", encoding="utf-8") as file:
    json.dump(summary, file, indent=2)

print(json.dumps(summary, indent=2))
print(f"\nSummary saved to: {OUTPUT_FILE}")
